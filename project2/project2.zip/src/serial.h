#ifndef __SERIAL_H__
#define __SERIAL_H__

int compress_directory(char *directory_name);

#endif
